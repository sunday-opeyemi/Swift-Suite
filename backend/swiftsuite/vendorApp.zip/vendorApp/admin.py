from django.contrib import admin
from .models import VendoEnronment
# Register your models here.

admin.site.register(VendoEnronment)